import { BaseComponent } from './BaseComponent';

export class UserButton extends BaseComponent {
  constructor(...args) {
    super(...args);
  }
}
