import  {BaseComponent } from './BaseComponent';

export class Header extends BaseComponent {
  constructor(options = {}) {
  }
  render = () => {
  }
}
